<?php

class ArticleCategory extends AppModel {
	public $name = 'ArticleCategory';
	
}

?>