<?php

class Video extends AppModel {
	public $name = 'Video';
	
}

?>